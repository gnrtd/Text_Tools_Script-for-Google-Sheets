# Text Tools for Google Sheets

A lightweight automation that adds a custom **Text Tools** menu to Google Sheets:
- Convert to **UPPERCASE**
- Convert to **lowercase**
- Convert to **Proper Case**

No add-ons, no extensions — just pure Google Apps Script.

## 📌 Installation

1. Open your Google Sheet  
2. Go to **Extensions → Apps Script**  
3. Delete any code inside `Code.gs`  
4. Paste the content of `textTools.gs` from this repo  
5. Click **Save**  
6. Refresh the Google Sheet  
7. A new menu **Text Tools** will appear at the top

## 📂 Files

- `textTools.gs` — main script
- `README.md` — documentation

## ✅ Use Case Example

Raw data → cleaned in seconds with one click.

| Raw Input | Output (Proper Case) |
|-----------|------------------------|
| oLeSiA li | Olesia Li |
| JOHN DOE | John Doe |

## 🔗 How it works

The script adds a menu on open:

```
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("Text Tools")
    .addItem("To UPPERCASE", "toUpperCaseRange")
    .addItem("To lowercase", "toLowerCaseRange")
    .addItem("To Proper Case", "toProperCaseRange")
    .addToUi();
}
```

## 🧠 Author
Created by Olesia Li  
Mini-automation for database professionals and spreadsheet power users.

